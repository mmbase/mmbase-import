function checkMaximum(form, field, max) {

   var formField = document.forms[form][field];
   if (formField.value.length > max) {
      formField.value = formField.value.substring(0, max);
   } 
}
