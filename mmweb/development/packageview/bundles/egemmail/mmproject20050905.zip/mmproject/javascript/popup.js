function popup(page, width, height) {

   if (width == undefined) {
      width = 400;
   }
   if (height == undefined) {
      height = 300;
   }
      

   settings = "toolbar=no,location=no,directories=no,"+
              "status=yes,menubar=no,scrollbars=no,"+
              "resizable=no,width=" + width+",height=" + height;
             
   url = "page.jsp?page=" + page;
   
   name = page.replace('.', '');
   
   window.open(url, 'mmproject'+name, settings);
   
   return false;
}